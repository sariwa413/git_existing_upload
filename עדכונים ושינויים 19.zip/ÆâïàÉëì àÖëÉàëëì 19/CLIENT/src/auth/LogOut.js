import React from "react";
import { Button } from "@mui/material";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { removeToken } from "./authSlice";

const LogOut = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogoutClick = () => {
    dispatch(removeToken());
    navigate("/");
  };

  return (
    <Button variant="contained" color="primary" onClick={handleLogoutClick}>
      Logout
    </Button>
  );
};

export default LogOut;
